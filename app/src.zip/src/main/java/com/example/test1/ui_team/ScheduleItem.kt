package com.example.test1.ui_team

data class ScheduleItem(
    val text: String,
    val tagColor: String
)
